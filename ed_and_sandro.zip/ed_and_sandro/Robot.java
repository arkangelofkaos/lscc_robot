public class Robot {
    public String execute(String board) {
        return Integer.toString(board.indexOf("-"));
//        if (board.equals("0--------")) {
//            return "8";
//        }
//        return "0";
    }
}
