object MainScala {
  def main(args: Array[String]) {
    println(args(0))
  }
}