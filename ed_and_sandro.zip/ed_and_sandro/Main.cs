public class Player
{
    static void Main(string[] args)
    {
        System.Console.WriteLine(args[0]);
    }
}