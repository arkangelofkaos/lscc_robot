ARGV.each do|a|
  # puts "Argument: #{a}"
  puts ["rock","paper","scissors"][rand(3)]
end